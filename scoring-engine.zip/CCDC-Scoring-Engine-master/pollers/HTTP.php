<?PHP
	
function getPage($passedURL)
	{
		
		$curl = curl_init("http://" . $passedURL);
		
		// should curl return or print the data? true = return, false = print
    	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
		// set referer:
		curl_setopt($curl, CURLOPT_REFERER, "http://www.google.com/");
	
		// user agent:
		curl_setopt($curl, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
		
		// timeout in seconds
   		 curl_setopt($curl, CURLOPT_TIMEOUT, 2);
	
		// download the given URL, and return output
		$output = curl_exec($curl);
	
		// close the curl resource, and free system resources
		curl_close($curl);
		
		// return output
		return $output;
	}
	
function HTTP($teamNumber)
{
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$httpStatus = "";
	
	//Load Config
	$configKey = array_search("#HTTP & HTTPS", $teamConfig);
	$url = $teamConfig[$configKey+1];
	$webIP = $teamConfig[$configKey+2];
	$pre1 = $teamConfig[$configKey+3];
	$pre2 = $teamConfig[$configKey+4];
	$pre3 = $teamConfig[$configKey+5];
	$hash = $teamConfig[$configKey+6];
	
	//Test Code
	
	$webPage = getPage($url);
	
	//Hash Match
	if($hash == md5($webPage)):
		$httpStatus = '<font color="green">' . "OK" .'</font>';
	//If Hash fails try to match $pre terms
	elseif(preg_match('*' . $pre1 . '*', $webPage) == true && preg_match('*' . $pre2 . '*', $webPage) == true && preg_match('*' . $pre3 . '*', $webPage) == true):
		$httpStatus = '<font color="green">' . "OK" .'</font>';
	//If both fail it trys grabbing the page again using an IP
	else: {
		$IPWebPage = getPage($webIP);
		if($hash == md5($IPWebPage)):
			$httpStatus = '<font color="green">' . "OK" .'</font>';
		elseif(preg_match('*' . $pre1 . '*', $IPWebPage) == true && preg_match('*' . $pre2 . '*', $IPWebPage) == true && preg_match('*' . $pre3 . '*', $IPWebPage) == true):
			$httpStatus = '<font color="green">' . "OK" .'</font>';
		else:
			$httpStatus = '<font color="red">' . "ERROR" .'</font>';
		endif;
	}
	endif;
	
	//Add Status to array
	$statusArray[] = $httpStatus;
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "HTTP:" . $httpStatus . "\n");
	fclose($file);
	
}
?>