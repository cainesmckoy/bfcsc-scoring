<?PHP
$page = $_SERVER['PHP_SELF'];
$sec="60"; 
?>
<html>
<head>
<meta http-equiv="refresh" content="<?PHP echo $sec?>;URL='<?PHP echo "team3check.php"?>'">

<title>BIG yeet</title>

<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<p>If you exit this page scoring will stop</p>	
<form action="team3check.php" method="post">
<input type="submit" name="check" value="Check Services">
</form>

<?PHP
$teamNumbers = array(3);

if ($_SERVER["REQUEST_METHOD"] == "GET")
{
//	include('check.php');
	include('check3.php');
//        loadServices();
	loadServices3();
//        checkServices();
	checkServices3();
}

?>

<p>TEAM 1</p>
<?PHP
$lines = shell_exec('tail -11 score_logs/Team1.txt');

echo "<pre>$lines</pre>"
?>
<p>TEAM 2</p>
<?PHP
$lines2 = shell_exec('tail -11 score_logs/Team2.txt');


echo "<pre>$lines2</pre>";
?>
<p>TEAM 3</p>
<?PHP
$lines2 = shell_exec('tail -11 score_logs/Team3.txt');


echo "<pre>$lines2</pre>";
?>


</body>
</html>