<?PHP
//List of checked services
$services = array();
$teamConfig = array();
$statusArray = array();

function loadServices3()
{
	global $services;
	
	//Read conf file
	$services = file('configs/sys.conf', FILE_IGNORE_NEW_LINES);
	
	//Remove top instruction line
	unset ($services[0]);
	$services = array_values($services);
	
	for($i = 0; $i < count($services); $i++)
	{
		//Include each poller that was in the conf file
		include('pollers/' . $services[$i] . ".php");
	}
}

function checkServices3()
{
	global $services;
	global $teamNumbers;
	global $teamConfig;
	global $statusArray;
	
	
	//Run for each team
	for($i = 0; $i < count($teamNumbers); $i++) {
		//increasing teamNumber will generate logs from the other teams
		$teamNumber = $i+3;
		
		//Load Config file
		$teamConfig = file('configs/Team' . $teamNumber . '.conf', FILE_IGNORE_NEW_LINES);
		
		$statusArray = array();
		
		//Run each service check
		for($index = 0; $index < count($services); ++$index) {
			$services[$index]($teamNumber);
		}
		
		//Write current status to team file
		$file = fopen('status/Team' . $teamNumber . '.status',"w");
		
		for($count = 0; $count < count($services); ++$count) {
			fwrite($file,$services[$count] . "," . $statusArray[$count] . ",");
		}
		fclose($file);
	}
	unset($statusArray);
}


?>
