<html>
<head>
<title>CCDC Scoring Engine</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<form action="admin-check.php" method="post">
<input type="submit" name="check" value="Check Services">
<p><b>bfcsc-scoring</b><p>
<p>teams Webpage(s) needs to be pulled up on a 'neutral machine' (SCOREBOX)
</p>
<p>+team1check.php handles team 1 scoring +team2check.php handles team 2 scoring +team3check.php handles team 3 scoring
</p>
<p>-the duplicate files handles get and post request for scoring machines
</p>
<p>+to add more teams check(2/3).php need to be duplicated also
</p>
<p>+display only check(2/3).php for corrisponding teams to show live updates</p>
</form>
<?PHP
/*
$teamNumbers = array(1);

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	include('check.php');
	
	loadServices();
	checkServices();
}
include('status/table.php');
*/
?>

</body>
</html>
