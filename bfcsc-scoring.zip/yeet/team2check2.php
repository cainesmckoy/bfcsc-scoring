<?PHP
$page = $_SERVER['PHP_SELF'];
$sec="60"; 
?>
<html>
<head>
<meta http-equiv="refresh" content="<?PHP echo $sec?>;URL='<?PHP echo "team2check.php"?>'">

<title>BIG yeet</title>

<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
<p>If you exit this page scoring will stop</p>	
<form action="team2check.php" method="post">
<input type="submit" name="check" value="Check Services">
</form>

<?PHP
$teamNumbers = array(3);

if ($_SERVER["REQUEST_METHOD"] == "GET")
{
//	include('check.php');
	include('check2.php');
//        loadServices();
	loadServices2();
//        checkServices();
	checkServices2();
}

?>

<p>TEAM 1</p>
<?PHP
$lines = shell_exec('tail -11 score_logs/Team1.txt');

echo "<pre>$lines</pre>"
?>
<p>TEAM 2</p>
<?PHP
$lines2 = shell_exec('tail -11 score_logs/Team2.txt');


echo "<pre>$lines2</pre>";
?>
<p>TEAM 3</p>
<?PHP
$lines2 = shell_exec('tail -11 score_logs/Team3.txt');


echo "<pre>$lines2</pre>";
?>


</body>
</html>