<?PHP
function PING2($teamNumber)
{
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$httpStatus = "";
	
	//Load Config
    $configKey = array_search("#PING2", $teamConfig);
    
    $host1 = $teamConfig[$configKey+1];

    if( exec("ping -c 1 $host1 | grep icmp_seq=1") == true){
        $pingstatus = '<font color="green">' . "OK" .'</font>';
    }    
    else {
        $pingstatus = '<font color="red">' . "ERROR" .'</font>';
            
    }  
    array_push($statusArray, $pingstatus);
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "PING2:" . $pingstatus . "\n");
	fclose($file);      
    
}
?>