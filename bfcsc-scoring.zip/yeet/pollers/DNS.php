<?PHP
function DNS($teamNumber)
{
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$dnsStatus = "OK";	
	
	//Load Config
	$configKey = array_search("#DNS", $teamConfig);
	
	
	//Test Code
	//CONFIG
	$server = $teamConfig[$configKey+1];
	$dnsIP = $teamConfig[$configKey+2];

	
	if( exec("dig +short $server") == $dnsIP){
		$dnsStatus = '<font color="green">' . "OK" .'</font>';
		//echo "<br>DNS - If<br>";
	}
	else {
		$dnsStatus = '<font color="red">' . "ERROR" .'</font>';
		//echo "<br>DNS - Else<br>";
	}
	
	array_push($statusArray, $dnsStatus);
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "DNS:" . $dnsStatus . "\n");
	fclose($file);
}
?>
