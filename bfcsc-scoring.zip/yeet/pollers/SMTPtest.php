<?PHP

function SMTPtest($teamNumber) {
	
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$smtpStatus = "";	
	
	//Load Config
    $configKey = array_search("#SMTPtest", $teamConfig);
    
	$emailip = $teamConfig[$configKey+1];
	$dnsname = $teamConfig[$configKey+2];
	$dnsip = $teamConfig[$configKey+3];
	$dns2name = $teamConfig[$configKey+4];
	$dns2ip = $teamConfig[$configKey+5];	

    if( exec("sendmail cmunro03@baker.edu < /tmp/email.txt") == true){
        $smtpStatus = '<font color="green">' . "OK" .'</font>';
	}  
	//elseif( exec("dig @$dns2name $emailip MX | grep '$dns2ip'") == true){
		
		//$smtpStatus = '<font color="green">' . "OK" .'</font>';
	//}  
    else {
        $smtpStatus = '<font color="red">' . "ERROR" .'</font>';
    }
    array_push($statusArray, $smtpStatus);
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "SMTP-TEST:" . $smtpStatus . "\n");
	fclose($file);      
    
}
?>