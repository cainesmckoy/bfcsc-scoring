<html>
<head>
<title>CCDC Scoring Engine</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<form action="index.php" method="post">
<input type="submit" name="check" value="Check Services">
</form>
<?PHP
$teamNumbers = array(1);

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	include('check.php');
	
	loadServices();
	checkServices();
}
include('status/table.php');

?>

</body>
</html>
