<?PHP

for($i = 0; $i < count($teamNumbers); $i++) {
	
	$teamNumber = $i+1;

	//Create lastCheck file for the team if it doesn't exist
	if (file_exists('status/Team' . $teamNumber . '.status')) {
	} else {
		$file = fopen('status/Team' . $teamNumber . '.status', "w");
		fclose($file);
	}
	
	//Store each line config in it's own array index
	$lines = file_get_contents('status/Team' . $teamNumber . '.status');
	
	//Split services at ,
	$status = explode(",", $lines);
	
	
	//Status Table
	echo '<h2> ' . 'Team ' . $teamNumber . ' </h2><table>';
	for($count = 0; $count < count($status); $count+=2) {
			echo '<tr><td class="' . $status[$count+1] . '">' . $status[$count] . '</td></tr>';
		}
	echo 
	'</table>';
}


?>