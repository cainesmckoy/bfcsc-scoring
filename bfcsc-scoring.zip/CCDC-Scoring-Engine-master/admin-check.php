<?PHP
$page = $_SERVER['PHP_SELF'];
$sec="60"; 
?>
<html>
<head>
<meta http-equiv="refresh" content="<?PHP echo $sec?>;URL='<?PHP echo "admin-check.php"?>'">

<title>CCDC Scoring Engine</title>

<link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<p>TEAM 1</p>
<?PHP
$lines = shell_exec('tail -7 score_logs/Team1.txt');

echo "<pre>$lines</pre>"
?>
<p>TEAM 2</p>
<?PHP
$lines2 = shell_exec('tail -7 score_logs/Team2.txt');


echo "<pre>$lines2</pre>";
?>
<p>TEAM 3</p>
<?PHP
$lines2 = shell_exec('tail -7 score_logs/Team3.txt');


echo "<pre>$lines2</pre>";
?>

</body>
</html>