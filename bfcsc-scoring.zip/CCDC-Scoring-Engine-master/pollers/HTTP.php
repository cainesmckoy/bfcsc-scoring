<?PHP
	
function getPage($passedURL)
	{
		
		$curl = curl_init("http://" . $passedURL );
		
		// should curl return or print the data? true = return, false = print
    	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
		// set referer:
		curl_setopt($curl, CURLOPT_REFERER, "http://www.google.com/");
	
		// user agent:
		//change this line to something strange as a log canary
		curl_setopt($curl, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
		
		// timeout in seconds
   		 curl_setopt($curl, CURLOPT_TIMEOUT, 2);
	
		// download the given URL, and return output
		$output = curl_exec($curl);
	
		// close the curl resource, and free system resources
		curl_close($curl);
		
		// return output
		return $output;
	}
	
function HTTP($teamNumber)
{
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$httpStatus = "";
	
	//Load Config
	$configKey = array_search("#HTTP & HTTPS", $teamConfig);
	$url = $teamConfig[$configKey+1];
	$webIP = $teamConfig[$configKey+2];
	$pre1 = $teamConfig[$configKey+3];
	$pre2 = $teamConfig[$configKey+4];
	$pre3 = $teamConfig[$configKey+5];
	$hash = $teamConfig[$configKey+6];
	
	//Test Code
	
	$webPage = getPage($url);
	$IPWebPage = getPage($webIP);
	//Hash Match
	
	if(exec("curl http://$webIP/yeet | grep 'YEET 12345qwerty'")):{
		$httpStatus = '<font color="green">' . "OK" .'</font>';  
	} 
	else: 
        $httpStatus = '<font color="red">' . "ERROR" .'</font>';
	endif;     
    

	
	//Add Status to array
	$statusArray[] = $httpsStatus;
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "HTTP:" . $httpStatus . "\n");
	fclose($file);
	
}
?>