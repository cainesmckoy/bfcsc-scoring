<?PHP

function FTP($teamNumber) {
	
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$ftpStatus = "";	
	
	//Load Config
	$configKey = array_search("#FTP", $teamConfig);
	
	
	//Test Code
	//CONFIG
	$server = $teamConfig[$configKey+1];
	$ftpIP = $teamConfig[$configKey+2];
	$ftpUser = $teamConfig[$configKey+3];
	$ftpPass = $teamConfig[$configKey+4];
	$hash = $teamConfig[$configKey+5];
	$server_file = $teamConfig[$configKey+6];
	$local_file = 'pollers/ftp_files/Team' . $teamNumber . '--' . $server_file;

	// set up basic connection
	$conn_id = @ftp_connect($server);
	
	// login with username and password
	$login_result = @ftp_login($conn_id, $ftpUser, $ftpPass);
	
	// try to download $server_file and save to $local_file
	if (@ftp_get($conn_id, $local_file, $server_file, FTP_BINARY)) {
		if($hash == md5_file($local_file)) {
			$ftpStatus = "OK";
		}
		else {
			$ftpStatus = "ERROR";
		}
	// Try using IP instead of URL
	} else {
		// Pass the IP not the URL
		$conn_id = @ftp_connect($ftpIP);
		$login_result = @ftp_login($conn_id, $ftpUser, $ftpPass);
		if (@ftp_get($conn_id, $local_file, $server_file, FTP_BINARY)) {
			if($hash == md5_file($local_file)) {
				$ftpStatus = '<font color="green">' . "OK" .'</font>';
			}
			else {
				$ftpStatus = '<font color="red">' . "ERROR" .'</font>';
			}
		}
		else {
			$ftpStatus = '<font color="red">' . "ERROR" .'</font>';
		}
		@ftp_close($conn_id);
	}
	// close the connection
	@ftp_close($conn_id);
	
	
	
	array_push($statusArray, $ftpStatus);
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "FTP:" . $ftpStatus . "\n");
	fclose($file);


}

?>