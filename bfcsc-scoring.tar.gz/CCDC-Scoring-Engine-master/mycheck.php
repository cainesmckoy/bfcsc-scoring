<?PHP
$page = $_SERVER['PHP_SELF'];
$sec="10"; 
?>
<html>
<head>
<meta http-equiv="refresh" content="<?PHP echo $sec?>;URL='<?PHP echo "mycheck2.php"?>'">
<title>CCDC Scoring Engine</title>
</head>
<body>
<p>If you exit this page scoring will stop</p>	
<form action="mycheck2.php" method="post">
<input type="submit" name="check" value="Check Services">
</form>



<?PHP
$teamNumbers = array(2);

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
        include('check.php');
//        include('check2.php');
        loadServices();
//        loadServices2();
        checkServices();
//        checkServices2();
}

?>
<p>TEAM 1</p>
<?PHP
$lines = shell_exec('tail -3 score_logs/Team1.txt');

echo "<pre>$lines</pre>"
?>
<p>TEAM 2</p>
<?PHP
$lines2 = shell_exec('tail -3 score_logs/Team2.txt');


echo "<pre>$lines2</pre>";
?>


</body>
</html>
