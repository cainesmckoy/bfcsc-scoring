CCDC-Scoring-Engine
===================

A scoring engine for CCDC.
