<?PHP

		$curl = curl_init("http://192.168.1.116");
		
		// should curl return or print the data? true = return, false = print
    	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
		// set referer:
		curl_setopt($curl, CURLOPT_REFERER, "http://www.google.com/");
	
		// user agent:
		curl_setopt($curl, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
		
		// timeout in seconds
   		curl_setopt($curl, CURLOPT_TIMEOUT, 2);
	
		// download the given URL, and return output
		$output = curl_exec($curl);
	
		// close the curl resource, and free system resources
		curl_close($curl);
	
		// print output
		echo $output;
		
		if($output == "")
		echo "NULL";

?>