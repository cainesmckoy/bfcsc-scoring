<?PHP
	
function getHTTPSPage($passedURL)
	{
		
		$curl = curl_init("https://" . $passedURL);
		
		// should curl return or print the data? true = return, false = print
    	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
		// set referer:
		curl_setopt($curl, CURLOPT_REFERER, "http://www.google.com/");
	
		// user agent:
		curl_setopt($curl, CURLOPT_USERAGENT, "MozillaXYZ/1.0");
		
		// Don't verify the certificate
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		
		// timeout in seconds
   		 curl_setopt($curl, CURLOPT_TIMEOUT, 2);
	
		// download the given URL, and return output
		$output = curl_exec($curl);
	
		// close the curl resource, and free system resources
		curl_close($curl);
		
		// return output
		return $output;
	}
	
function HTTPS($teamNumber)
{
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$httpsStatus = "";
	
	//Load Config
	$configKey = array_search("#HTTP & HTTPS", $teamConfig);
	$url = $teamConfig[$configKey+1];
	$webIP = $teamConfig[$configKey+2];
	$pre1 = $teamConfig[$configKey+3];
	$pre2 = $teamConfig[$configKey+4];
	$pre3 = $teamConfig[$configKey+5];
	$hash = $teamConfig[$configKey+6];
	
	//Test Code
	$webPage = getHTTPSPage($url);
	
	//Hash Match
	if($hash == md5($webPage)):
		$httpsStatus = "OK";
	//If Hash fails try to match $pre terms
	elseif(preg_match('*' . $pre1 . '*', $webPage) == true && preg_match('*' . $pre2 . '*', $webPage) == true && preg_match('*' . $pre3 . '*', $webPage) == true):
		$httpsStatus = "OK";
	//If both fail it trys grabbing the page again using an IP
	else: {
		$IPWebPage = getHTTPSPage($webIP);
		if($hash == md5($IPWebPage)):
			$httpsStatus = "OK";
		elseif(preg_match('*' . $pre1 . '*', $IPWebPage) == true && preg_match('*' . $pre2 . '*', $IPWebPage) == true && preg_match('*' . $pre3 . '*', $IPWebPage) == true):
			$httpsStatus = "OK";
		else:
			$httpsStatus = "ERROR";
		endif;
	}
	endif;
	
	//Add Status to array
	$statusArray[] = $httpsStatus;
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "HTTPS:" . $httpsStatus . "\n");
	fclose($file);
	
}
?>