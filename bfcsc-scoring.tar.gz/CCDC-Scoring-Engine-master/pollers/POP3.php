<?PHP
function POP3($teamNumber)
{
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	
	$pop3Status = "";
	
	//Test Code
	$pop3Status = "ERROR";
	
	array_push($statusArray, $pop3Status);
	
	//LOG Status
	if (file_exists('scores/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('scores/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('scores/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "POP3:" . $pop3Status . "\n");
	fclose($file);
}
?>