<?PHP

function SSH($teamNumber) {
	
	//Don't Fuck With This
	date_default_timezone_set('America/Chicago');
	global $statusArray;
	global $teamConfig;
	$sshStatus = "";	
	
	//Load Config
	$configKey = array_search("#SSH", $teamConfig);
	
	
	//Test
	$server = $teamConfig[$configKey+1];
	$sshIP = $teamConfig[$configKey+2];
	$sshUser = $teamConfig[$configKey+3];
	$sshPass = $teamConfig[$configKey+4];
	
	/*if (!($connection = ssh2_connect($server, 22))) {
		echo "fail: unable to establish connection\n";	
	}
	else {*/
	$connection = @ssh2_connect($server, 22);
	
		if (@ssh2_auth_password($connection, $sshUser, $sshPass)) {
			$sshStatus = "OK";
		} 
		else {
			$backUpConnection = @ssh2_connect($sshIP, 22);
			
			if (@ssh2_auth_password($backUpConnection, $sshUser, $sshPass)) {
				$sshStatus = "OK";
			} 
			else {
				$sshStatus = "ERROR";
			}
		}
//	}
	
	
	array_push($statusArray, $sshStatus);
	
	//LOG Status
	if (file_exists('score_logs/Team' . $teamNumber . '.txt')) {} 
	else {
	$file = fopen('score_logs/Team' . $teamNumber . '.txt', "w");
	fclose($file);
	}
	
	$file = fopen('score_logs/Team' . $teamNumber . '.txt',"a+");
	fwrite($file, date("m/d/y G.i:s", time()) . " - " . "SSH:" . $sshStatus . "\n");
	fclose($file);
}
?>
